<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Nombre_Programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Quit application</source>
        <translation>Terminar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="49"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="87"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="90"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="96"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="112"/>
        <source>Back</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="169"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="194"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="197"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="203"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>View Log</source>
        <translation>Ver registro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="745"/>
        <location filename="../src/mainwindow.cpp" line="600"/>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <source>Select ISO</source>
        <translation>Seleccione ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="541"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Target USB Device&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleccione Dispositivo USB Destino&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="247"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select ISO file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Seleccione fichero ISO&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="263"/>
        <source>Advanced Options</source>
        <translation>Opciones avanzadas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="375"/>
        <source>Make the ext4 filesystem even if one exists</source>
        <translation>Crear el sistema de archivos ext4 incluso si ya existe uno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="382"/>
        <source>Save the original boot directory when updating a live-usb</source>
        <translation>Guardar el directorio de arranque original al actualizar un live-usb</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="389"/>
        <source>Use gpt partitioning instead of msdos</source>
        <translation>Usar particionamiento gpt en vez de msdos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>GPT partitioning</source>
        <translation>Particionamiento GPT</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="399"/>
        <source>Update (only update an existing live-usb)</source>
        <translation>Actualizar (solamente actualiza un liveUSB existente)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="406"/>
        <source>Don&apos;t replace syslinux files</source>
        <translation>No reemplazar archivos syslinux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="409"/>
        <source>Keep syslinux files</source>
        <translation>Mantener archivos syslinux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="416"/>
        <source>Ignore USB/removable check</source>
        <translation>Ignorar chequeo USB/removible</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="423"/>
        <source>Temporarily disable automounting</source>
        <translation>Temporalmente deshabilitar automontaje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <source>Set pmbr_boot disk flag (won&apos;t boot via UEFI)</source>
        <translation>Fijar bandera disco a pmbr_boot (no iniciar via UEFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="440"/>
        <source>Don&apos;t use fuseiso to mount iso files</source>
        <translation>No use fuseiso para montar archivos iso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="288"/>
        <source>Size of ESP (uefi) partition:</source>
        <translation>Tamaño del partición ESP (uefi):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="353"/>
        <source>Verbosity (less to more):</source>
        <translation>Verbosidad (de menos a más)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="329"/>
        <source>vfat</source>
        <translation>vfat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="478"/>
        <source>Data partition format type</source>
        <translation>Tipo de formato de partición de datos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="324"/>
        <source>exfat</source>
        <translation>exfat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="334"/>
        <source>ext4</source>
        <translation>ext4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="339"/>
        <source>ntfs</source>
        <translation>ntfs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="281"/>
        <source>Make separate data partition (percent)</source>
        <translation>Crear una partición de datos separada (porcentaje)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="768"/>
        <source>Refresh drive list</source>
        <translation>Refrescar lista de dispositivos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="755"/>
        <location filename="../src/mainwindow.cpp" line="560"/>
        <source>Show advanced options</source>
        <translation>Mostrar opciones avanzadas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="787"/>
        <source>Mode</source>
        <translation>Modo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="808"/>
        <source>Full-featured mode - writable Li&amp;veUSB</source>
        <translation>Modo de funciones completas - Li&amp;veUSB escribible</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="818"/>
        <source>Read-only, cannot be used with persistency</source>
        <translation>Leer solamente, no soporta persistencía</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="821"/>
        <source>Image &amp;mode - read-only LiveUSB (dd)</source>
        <translation>Modo de i&amp;magen: Live USB de solo lectura (dd)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="840"/>
        <source>For distros other than antiX/MX use image mode (dd).</source>
        <translation>Para distros no antiX/MX utilizar el modo imagen (dd).</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="557"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="607"/>
        <source>Percent of USB-device to use:</source>
        <translation>Porcentaje del dispositivo USB a utilizar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="620"/>
        <source>Label ext partition:</source>
        <translation>Etiqueta para partición ext:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="642"/>
        <source>Don&apos;t run commands that affect the usb device</source>
        <translation>No ejecuta comandos que afecta el dispositivo USB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="645"/>
        <source>Dry run (no change to system)</source>
        <translation>Modo simulación (ningún cambio al sistema)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="652"/>
        <source>clone from a mounted live-usb or iso-file.</source>
        <translation>clonar de un liveUSB montado o un fichero ISO.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="655"/>
        <source>Clone a mounted live system</source>
        <translation>Clonar un sistema en vivo montado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="662"/>
        <source>Set up to boot from an encrypted partition, will prompt for pass phrase on first boot</source>
        <translation>Configurar para iniciar desde una partición cifrada; preguntará la frase de paso en el primer arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="665"/>
        <source>Encrypt</source>
        <translation>Cifrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="672"/>
        <source>Clone running live system</source>
        <translation>Clonar el sistema que se ejecuta en vivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <location filename="../src/mainwindow.cpp" line="545"/>
        <location filename="../src/mainwindow.cpp" line="722"/>
        <source>Failure</source>
        <translation>Falla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="155"/>
        <source>Source and destination are on the same device, please select again.</source>
        <translation>La fuente y el destino están en el mismo dispositivo; seleccionar de nuevo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="767"/>
        <source>Source Error</source>
        <translation>Error de fuente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="768"/>
        <source>Could not find the source linuxfs file.</source>
        <translation>No se pudo encontrar el archivo fuente linuxfs.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="789"/>
        <source>Warning: The target device (%1) is smaller than the source (%2). The data might not fit. Do you want to continue?</source>
        <translation>Advertencia: El dispositivo de destino (%1) es más pequeño que el de origen (%2). Los datos podrían no caber. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="792"/>
        <source>Size Warning</source>
        <translation>Advertencia de tamaño</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="800"/>
        <source>The target device %1 is larger than %2 GB.

This may indicate you have selected the wrong device.
Are you sure you want to proceed?</source>
        <translation>El dispositivo destino %1 es mayor en %2 GB.Esto puede indicar que ha seleccionado el dispositivo equivocado.¿Está seguro que desea continuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="807"/>
        <source>Large Target Device Warning</source>
        <translation>Advertencia de dispositivo objetivo grande</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="194"/>
        <source>Writing %1 using 'dd' command to /dev/%2,

Please wait until the process is completed</source>
        <translation>Escribiendo %1 con el comando &apos;dd&apos; hacia /dev/%2,

Por favor espere hasta que se complete el proceso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="205"/>
        <source>MX Live Usb Maker</source>
        <translation>MX Creador Live-Usb</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="395"/>
        <source>Success</source>
        <translation>Éxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="395"/>
        <source>LiveUSB creation successful!</source>
        <translation>¡Creación del LiveUSB exitosa!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="398"/>
        <source>Error encountered in the LiveUSB creation process</source>
        <translation>Se encontró un error en el proceso de creación del LiveUSB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="464"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="464"/>
        <source>Please select a USB device to write to</source>
        <translation>Favor seleccione el dispositivo USB al cual escribir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="470"/>
        <source>Update mode is selected. The live system on %1 will be updated with the new ISO without reformatting the device.

Existing data and persistence should remain, but please back up anything important.

Do you wish to continue?</source>
        <translation>Se ha seleccionado el modo de actualización. El sistema en funcionamiento en %1 se actualizará con la nueva ISO sin reformatear el dispositivo.

Los datos existentes y la persistencia deberían conservarse, pero le recomendamos que haga una copia de seguridad de cualquier información importante.

¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="475"/>
        <source>These actions will destroy all data on 

</source>
        <translation>Estas acciones destruirían todos los datos en el

</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="475"/>
        <source>Do you wish to continue?</source>
        <translation>¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="508"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="509"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="511"/>
        <source>Program for creating a live-usb from an iso-file, another live-usb, a live-cd/dvd, or a running live system.</source>
        <translation>Programa para crear liveUSB desde un fichero ISO, otro liveUSB, liveCD/DVD, o un sistema actualmente en ejecución.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="514"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="522"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="530"/>
        <source>Select an ISO file to write to the USB drive</source>
        <translation>Seleccione fichero ISO para escribir al USB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="531"/>
        <source>ISO Files (*.iso);;All Files (*.*)</source>
        <translation>Archivos ISO (*.iso);;Todos los archivos (*.*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <location filename="../src/mainwindow.cpp" line="595"/>
        <source>Select Source Directory</source>
        <translation>Seleccione Carpeta Fuente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="545"/>
        <source>Could not find linuxfs file</source>
        <translation>No se pudo encontar el archivo linuxfs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="560"/>
        <source>Hide advanced options</source>
        <translation>Esconder opciones avanzadas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="594"/>
        <location filename="../src/mainwindow.cpp" line="613"/>
        <source>Select Source</source>
        <translation>Seleccionar Fuente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="599"/>
        <location filename="../src/mainwindow.cpp" line="621"/>
        <source>Select ISO file</source>
        <translation>Seleccionar fichero ISO</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="615"/>
        <source>clone</source>
        <translation>clonar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="682"/>
        <source>Could not find a log file at: </source>
        <translation>No se pudo encontrar un archivo de registro en:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="74"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <location filename="../src/about.cpp" line="85"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="76"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="99"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="60"/>
        <source>Program for creating a live-usb from an iso-file, another live-usb, a live-cd/dvd, or a running live system.</source>
        <translation>Programa para crear liveUSB desde un fichero ISO, otro liveUSB, liveCD/DVD, o un sistema actualmente en ejecución.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>filename</source>
        <translation>Nombre del archivo</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Name of .iso file to open</source>
        <translation>Nombre del archivo .iso para abrir</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="65"/>
        <source>[filename]</source>
        <translation>[Nombre del archivo]</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <location filename="../src/main.cpp" line="102"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="102"/>
        <source>You must run this program as root.</source>
        <translation>Debe ejecutar este programa como root.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>version:</source>
        <translation>versión:</translation>
    </message>
</context>
</TS>