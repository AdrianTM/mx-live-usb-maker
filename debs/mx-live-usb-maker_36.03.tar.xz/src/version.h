inline const QString VERSION {"36.03"};
